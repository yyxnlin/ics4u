package withgraphics;
import java.util.Comparator;

public class SortByName implements Comparator <Episode>{

	public int compare(Episode e1, Episode e2) {
		return e1.getTitle().toLowerCase().compareTo(e2.getTitle().toLowerCase());
	}
	
}
