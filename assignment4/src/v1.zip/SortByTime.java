import java.util.Comparator;

public class SortByTime implements Comparator <Episode>{

	@Override
	public int compare(Episode e1, Episode e2) {
		return (e1.getTime().getDifference(e2.getTime()));
	}
	

}
